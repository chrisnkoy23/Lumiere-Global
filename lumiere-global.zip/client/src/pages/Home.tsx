import { Mail, Phone, MapPin, ArrowRight, Zap, Globe, Brain, Lock } from "lucide-react";
import { useState, useRef } from "react";
import { MapView } from "@/components/Map";
import { Button } from "@/components/ui/button";

export default function Home() {
  const [language, setLanguage] = useState<"en" | "fr">("en");
  const [contactForm, setContactForm] = useState({
    name: "",
    email: "",
    message: "",
  });
  const mapRef = useRef<HTMLDivElement>(null);

  // Translation object
  const translations = {
    en: {
      mission: "Mission",
      services: "Services",
      community: "Community",
      contact: "Contact",
      tagline: "Illuminating Global Solutions",
      heroDescription:
        "Transform your healthcare systems with cutting-edge biomedical informatics, AI-driven insights, and expert consulting tailored to your facility's unique needs.",
      getStarted: "Get Started",
      learnMore: "Learn More",
      ourMission: "Our Mission",
      missionText:
        "At Lumière Global, we provide world-class healthcare consulting that integrates biomedical informatics and cutting-edge technology to improve patient outcomes and operational efficiency.",
      visionText:
        "Our vision is to become the premier global partner for healthcare institutions seeking to modernize their infrastructure and adopt AI-driven solutions that transform how they deliver care.",
      professionalExcellence: "Professional Excellence",
      professionalDesc: "Delivering solutions grounded in research and best practices",
      globalPerspective: "Global Perspective",
      globalDesc: "Understanding diverse markets and cultural contexts",
      innovationFirst: "Innovation First",
      innovationDesc: "Staying ahead of technology trends in healthcare",
      globalReach: "Global Reach",
      globalReachDesc: "US-based with expertise in European and African markets",
      biomedicalExpertise: "Biomedical Expertise",
      biomedicalDesc: "Deep knowledge in healthcare informatics and systems",
      aiDriven: "AI-Driven Solutions",
      aiDesc: "Leveraging AI to transform healthcare delivery",
      ourServices: "Our Services",
      servicesDesc:
        "Comprehensive consulting solutions tailored to your healthcare facility's unique needs and growth trajectory",
      systemsIntegration: "Healthcare Systems Integration",
      systemsDesc:
        "Expert guidance on selecting and implementing EHR and hospital management systems that streamline operations and improve patient care.",
      operationalOptimization: "Operational Optimization",
      operationalDesc:
        "Streamlining hospital workflows to reduce costs, improve efficiency, and enhance patient throughput across all departments.",
      techInfrastructure: "Tech Infrastructure Consulting",
      techDesc:
        "Designing robust digital foundations that support future scalability, security, and compliance with healthcare regulations.",
      aiImplementation: "AI & Advanced Tech Implementation",
      aiImplDesc:
        "Moving beyond traditional systems to integrate machine learning, predictive analytics, and AI-driven insights into clinical practice.",
      forCommunity: "For the Healthcare & Tech Community",
      communityText:
        "We believe in fostering a vibrant community of healthcare professionals, technology innovators, and forward-thinking leaders. Our consulting approach is rooted in collaboration, transparency, and a shared commitment to advancing global healthcare.",
      facilitiesServed: "Healthcare Facilities Served",
      yearsExperience: "Years of Combined Expertise",
      continents: "Continents of Operations",
      whyChoose: "Why Choose Lumière Global?",
      getInTouch: "Get in Touch",
      touchDesc:
        "Let's discuss how Lumière Global can illuminate your path to healthcare excellence",
      contactInfo: "Contact Information",
      emailLabel: "Email",
      phoneLabel: "Phone",
      location: "Location",
      serviceAreas: "Service Areas",
      globalMap: "Global Service Areas",
      mapDesc:
        "We serve healthcare institutions across the United States, French-speaking Europe, and French-speaking Africa.",
      sendMessage: "Send Message",
      about: "About Us",
      company: "Company",
      copyright: "© 2024 Lumière Global. All rights reserved.",
      learnMoreArrow: "Learn more →",
    },
    fr: {
      mission: "Mission",
      services: "Services",
      community: "Communauté",
      contact: "Contact",
      tagline: "Illuminant les Solutions Mondiales",
      heroDescription:
        "Transformez vos systèmes de santé avec l'informatique biomédicale de pointe, les insights alimentés par l'IA et le conseil expert adapté aux besoins uniques de votre établissement.",
      getStarted: "Commencer",
      learnMore: "En Savoir Plus",
      ourMission: "Notre Mission",
      missionText:
        "Chez Lumière Global, nous fournissons un conseil en santé de classe mondiale qui intègre l'informatique biomédicale et la technologie de pointe pour améliorer les résultats des patients et l'efficacité opérationnelle.",
      visionText:
        "Notre vision est de devenir le partenaire mondial de premier plan pour les institutions de santé cherchant à moderniser leur infrastructure et à adopter des solutions alimentées par l'IA.",
      professionalExcellence: "Excellence Professionnelle",
      professionalDesc: "Fournir des solutions fondées sur la recherche et les meilleures pratiques",
      globalPerspective: "Perspective Mondiale",
      globalDesc: "Comprendre les marchés et les contextes culturels diversifiés",
      innovationFirst: "Innovation d'Abord",
      innovationDesc: "Rester à l'avant-garde des tendances technologiques en santé",
      globalReach: "Portée Mondiale",
      globalReachDesc: "Basé aux États-Unis avec expertise sur les marchés européens et africains",
      biomedicalExpertise: "Expertise Biomédicale",
      biomedicalDesc: "Connaissance approfondie de l'informatique de santé et des systèmes",
      aiDriven: "Solutions Alimentées par l'IA",
      aiDesc: "Exploiter l'IA pour transformer la prestation de soins de santé",
      ourServices: "Nos Services",
      servicesDesc:
        "Des solutions de conseil complètes adaptées aux besoins uniques et à la trajectoire de croissance de votre établissement de santé",
      systemsIntegration: "Intégration des Systèmes de Santé",
      systemsDesc:
        "Conseils d'experts sur la sélection et la mise en œuvre des systèmes de dossiers médicaux électroniques et de gestion hospitalière.",
      operationalOptimization: "Optimisation Opérationnelle",
      operationalDesc:
        "Rationaliser les flux de travail hospitaliers pour réduire les coûts, améliorer l'efficacité et améliorer le débit des patients.",
      techInfrastructure: "Conseil en Infrastructure Technologique",
      techDesc:
        "Concevoir des fondations numériques robustes qui soutiennent l'évolutivité future, la sécurité et la conformité réglementaire.",
      aiImplementation: "Mise en Œuvre de l'IA et de la Technologie Avancée",
      aiImplDesc:
        "Aller au-delà des systèmes traditionnels pour intégrer l'apprentissage automatique, l'analyse prédictive et les insights alimentés par l'IA.",
      forCommunity: "Pour la Communauté de la Santé et de la Technologie",
      communityText:
        "Nous croyons en la création d'une communauté dynamique de professionnels de la santé, d'innovateurs technologiques et de leaders visionnaires.",
      facilitiesServed: "Établissements de Santé Servis",
      yearsExperience: "Années d'Expertise Combinée",
      continents: "Continents d'Opération",
      whyChoose: "Pourquoi Choisir Lumière Global?",
      getInTouch: "Entrez en Contact",
      touchDesc:
        "Discutons de la façon dont Lumière Global peut illuminer votre chemin vers l'excellence en santé",
      contactInfo: "Informations de Contact",
      emailLabel: "Email",
      phoneLabel: "Téléphone",
      location: "Localisation",
      serviceAreas: "Zones de Service",
      globalMap: "Zones de Service Mondiales",
      mapDesc:
        "Nous servons les établissements de santé aux États-Unis, en Europe francophone et en Afrique francophone.",
      sendMessage: "Envoyer le Message",
      about: "À Propos",
      company: "Entreprise",
      copyright: "© 2024 Lumière Global. Tous droits réservés.",
      learnMoreArrow: "En savoir plus →",
    },
  };

  const t = translations[language];

  const handleContactChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setContactForm((prev) => ({ ...prev, [name]: value }));
  };

  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Form submitted:", contactForm);
    alert(
      language === "en"
        ? "Thank you for your interest! We'll be in touch soon."
        : "Merci de votre intérêt! Nous vous recontacterons bientôt."
    );
    setContactForm({ name: "", email: "", message: "" });
  };

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-border z-50">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <img
              src="/manus-storage/lumiere-logo_744079e8.png"
              alt="Lumière Global"
              className="h-12 w-auto"
            />
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#mission" className="text-sm hover:text-accent transition-colors">
              {t.mission}
            </a>
            <a href="#services" className="text-sm hover:text-accent transition-colors">
              {t.services}
            </a>
            <a href="#community" className="text-sm hover:text-accent transition-colors">
              {t.community}
            </a>
            <a href="#contact" className="text-sm hover:text-accent transition-colors">
              {t.contact}
            </a>
            <div className="flex items-center gap-2 border-l border-border pl-8">
              <button
                onClick={() => setLanguage("en")}
                className={`text-sm font-semibold transition-colors ${
                  language === "en" ? "text-primary" : "text-foreground/50 hover:text-foreground"
                }`}
              >
                EN
              </button>
              <span className="text-foreground/30">|</span>
              <button
                onClick={() => setLanguage("fr")}
                className={`text-sm font-semibold transition-colors ${
                  language === "fr" ? "text-primary" : "text-foreground/50 hover:text-foreground"
                }`}
              >
                FR
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663693316764/kPgMHVgNnwTEkaspTVQZQa/hero-background-J3tmxPuVZdhfS4t5thc7uJ.webp')",
          }}
        />
        <div className="container relative z-10">
          <div className="max-w-3xl">
            <h1 className="font-display text-5xl md:text-6xl text-primary mb-6 leading-tight">
              {t.tagline}
            </h1>
            <p className="text-lg md:text-xl text-foreground/80 mb-8 max-w-2xl">
              {t.heroDescription}
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-primary hover:bg-primary/90 text-white rounded-lg transition-all hover:shadow-lg"
              >
                {t.getStarted} <ArrowRight className="ml-2 w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-primary text-primary hover:bg-primary/5 rounded-lg"
              >
                {t.learnMore}
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Mission Statement Section */}
      <section id="mission" className="py-20 bg-white">
        <div className="container">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-display text-4xl text-primary mb-6">{t.ourMission}</h2>
              <p className="text-foreground/80 text-lg mb-6 leading-relaxed">{t.missionText}</p>
              <p className="text-foreground/80 text-lg mb-6 leading-relaxed">{t.visionText}</p>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <div className="w-2 h-2 bg-accent rounded-full" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-1">
                      {t.professionalExcellence}
                    </h3>
                    <p className="text-sm text-foreground/70">{t.professionalDesc}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <div className="w-2 h-2 bg-accent rounded-full" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-1">{t.globalPerspective}</h3>
                    <p className="text-sm text-foreground/70">{t.globalDesc}</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-6 h-6 rounded-full bg-accent/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <div className="w-2 h-2 bg-accent rounded-full" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-primary mb-1">{t.innovationFirst}</h3>
                    <p className="text-sm text-foreground/70">{t.innovationDesc}</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-br from-accent/10 to-primary/5 rounded-2xl" />
              <div className="relative bg-white p-8 rounded-xl shadow-lg border border-border">
                <div className="space-y-6">
                  <div className="text-center">
                    <Globe className="w-12 h-12 text-accent mx-auto mb-3" />
                    <h3 className="font-semibold text-primary mb-2">{t.globalReach}</h3>
                    <p className="text-sm text-foreground/70">{t.globalReachDesc}</p>
                  </div>
                  <div className="h-px bg-border" />
                  <div className="text-center">
                    <Brain className="w-12 h-12 text-accent mx-auto mb-3" />
                    <h3 className="font-semibold text-primary mb-2">{t.biomedicalExpertise}</h3>
                    <p className="text-sm text-foreground/70">{t.biomedicalDesc}</p>
                  </div>
                  <div className="h-px bg-border" />
                  <div className="text-center">
                    <Zap className="w-12 h-12 text-accent mx-auto mb-3" />
                    <h3 className="font-semibold text-primary mb-2">{t.aiDriven}</h3>
                    <p className="text-sm text-foreground/70">{t.aiDesc}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20 relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-10"
          style={{
            backgroundImage:
              "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663693316764/kPgMHVgNnwTEkaspTVQZQa/services-background-6t4EKVpdtZY4q2ZTqTbuEs.webp')",
          }}
        />
        <div className="container relative z-10">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl text-primary mb-4">{t.ourServices}</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto">{t.servicesDesc}</p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Service Card 1 */}
            <div className="bg-white rounded-xl p-8 border border-border hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-semibold text-lg text-primary mb-3">{t.systemsIntegration}</h3>
              <p className="text-foreground/70 mb-4">{t.systemsDesc}</p>
              <a href="#" className="text-accent font-semibold text-sm hover:underline">
                {t.learnMoreArrow}
              </a>
            </div>

            {/* Service Card 2 */}
            <div className="bg-white rounded-xl p-8 border border-border hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-semibold text-lg text-primary mb-3">
                {t.operationalOptimization}
              </h3>
              <p className="text-foreground/70 mb-4">{t.operationalDesc}</p>
              <a href="#" className="text-accent font-semibold text-sm hover:underline">
                {t.learnMoreArrow}
              </a>
            </div>

            {/* Service Card 3 */}
            <div className="bg-white rounded-xl p-8 border border-border hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
                <Lock className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-semibold text-lg text-primary mb-3">{t.techInfrastructure}</h3>
              <p className="text-foreground/70 mb-4">{t.techDesc}</p>
              <a href="#" className="text-accent font-semibold text-sm hover:underline">
                {t.learnMoreArrow}
              </a>
            </div>

            {/* Service Card 4 */}
            <div className="bg-white rounded-xl p-8 border border-border hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 bg-accent/20 rounded-lg flex items-center justify-center mb-4">
                <Globe className="w-6 h-6 text-accent" />
              </div>
              <h3 className="font-semibold text-lg text-primary mb-3">{t.aiImplementation}</h3>
              <p className="text-foreground/70 mb-4">{t.aiImplDesc}</p>
              <a href="#" className="text-accent font-semibold text-sm hover:underline">
                {t.learnMoreArrow}
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Global Service Areas Map Section */}
      <section id="map" className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="font-display text-4xl text-primary mb-4">{t.globalMap}</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto">{t.mapDesc}</p>
          </div>

          <div
            ref={mapRef}
            className="rounded-xl overflow-hidden border border-border shadow-lg"
            style={{ height: "500px" }}
          >
            <MapView
              onMapReady={(map: google.maps.Map) => {
                // Set map center to show global view
                map.setCenter({ lat: 20, lng: 0 });
                map.setZoom(2);

                // Add markers for service regions
                const markers = [
                  {
                    position: { lat: 34.0522, lng: -118.2437 },
                    title: language === "en" ? "Los Angeles, CA" : "Los Angeles, CA",
                  },
                  {
                    position: { lat: 18.0179, lng: -76.8099 },
                    title: language === "en" ? "Kingston, Jamaica" : "Kingston, Jamaïque",
                  },
                  {
                    position: { lat: 43.6629, lng: -79.3957 },
                    title: language === "en" ? "Toronto, Canada" : "Toronto, Canada",
                  },
                  {
                    position: { lat: 48.8566, lng: 2.3522 },
                    title: language === "en" ? "France" : "France",
                  },
                  {
                    position: { lat: 50.8503, lng: 4.3517 },
                    title: language === "en" ? "Belgium" : "Belgique",
                  },
                  {
                    position: { lat: 46.8182, lng: 8.2275 },
                    title: language === "en" ? "Switzerland" : "Suisse",
                  },
                  {
                    position: { lat: -1.9536, lng: 29.8739 },
                    title: language === "en" ? "Rwanda" : "Rwanda",
                  },
                  {
                    position: { lat: -37.8136, lng: 144.9631 },
                    title: language === "en" ? "Melbourne, Australia" : "Melbourne, Australie",
                  },
                  {
                    position: { lat: -4.0383, lng: 21.758 },
                    title: language === "en" ? "Democratic Republic of Congo" : "République Démocratique du Congo",
                  },
                  {
                    position: { lat: -11.202, lng: 17.8739 },
                    title: language === "en" ? "Angola" : "Angola",
                  },
                  {
                    position: { lat: -18.7669, lng: 46.869 },
                    title: language === "en" ? "Madagascar" : "Madagascar",
                  },
                  {
                    position: { lat: -4.3876, lng: 55.1464 },
                    title: language === "en" ? "Mauritius" : "Île Maurice",
                  },
                  {
                    position: { lat: -13.1339, lng: 27.8493 },
                    title: language === "en" ? "Burundi" : "Burundi",
                  },
                  {
                    position: { lat: -1.6508, lng: 29.7418 },
                    title: language === "en" ? "Uganda" : "Ouganda",
                  },
                  {
                    position: { lat: 3.8667, lng: 11.5167 },
                    title: language === "en" ? "Cameroon" : "Cameroun",
                  },
                  {
                    position: { lat: 2.1454, lng: 29.8739 },
                    title: language === "en" ? "Equatorial Guinea" : "Guinée Équatoriale",
                  },
                  {
                    position: { lat: -0.6280, lng: 15.8277 },
                    title: language === "en" ? "Republic of Congo" : "République du Congo",
                  },
                  {
                    position: { lat: 3.8480, lng: 11.5021 },
                    title: language === "en" ? "Gabon" : "Gabon",
                  },
                  {
                    position: { lat: 4.0511, lng: -9.7679 },
                    title: language === "en" ? "Benin" : "Bénin",
                  },
                  {
                    position: { lat: 6.4969, lng: -1.0232 },
                    title: language === "en" ? "Ivory Coast" : "Côte d'Ivoire",
                  },
                  {
                    position: { lat: 12.5657, lng: -8.0026 },
                    title: language === "en" ? "Guinea" : "Guinée",
                  },
                  {
                    position: { lat: 13.5116, lng: -11.7799 },
                    title: language === "en" ? "Guinea-Bissau" : "Guinée-Bissau",
                  },
                  {
                    position: { lat: 14.4974, lng: -14.4524 },
                    title: language === "en" ? "Senegal" : "Sénégal",
                  },
                ];

                markers.forEach((markerData) => {
                  new window.google.maps.Marker({
                    position: markerData.position,
                    map: map,
                    title: markerData.title,
                  });
                });
              }}
            />
          </div>
        </div>
      </section>

      {/* Healthcare & Tech Community Section */}
      <section id="community" className="py-20 bg-white">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-4xl text-primary mb-8 text-center">{t.forCommunity}</h2>
            <p className="text-lg text-foreground/80 mb-12 text-center leading-relaxed">
              {t.communityText}
            </p>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="text-center">
                <div className="text-4xl font-display text-accent mb-3">50+</div>
                <p className="text-foreground/70">{t.facilitiesServed}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-display text-accent mb-3">15+</div>
                <p className="text-foreground/70">{t.yearsExperience}</p>
              </div>
              <div className="text-center">
                <div className="text-4xl font-display text-accent mb-3">3</div>
                <p className="text-foreground/70">{t.continents}</p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-xl p-8 border border-border">
              <h3 className="font-semibold text-primary mb-4">{t.whyChoose}</h3>
              <ul className="space-y-3 text-foreground/80">
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">✓</span>
                  <span>
                    {language === "en"
                      ? "Unique combination of clinical consulting and advanced biomedical informatics expertise"
                      : "Combinaison unique de conseil clinique et d'expertise avancée en informatique biomédicale"}
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">✓</span>
                  <span>
                    {language === "en"
                      ? "International perspective with deep understanding of both developed and emerging healthcare markets"
                      : "Perspective internationale avec compréhension approfondie des marchés de la santé développés et émergents"}
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">✓</span>
                  <span>
                    {language === "en"
                      ? "Future-ready solutions that prepare your facility for the AI-driven future of medicine"
                      : "Solutions prêtes pour l'avenir qui préparent votre établissement à l'avenir de la médecine alimentée par l'IA"}
                  </span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-accent font-bold mt-1">✓</span>
                  <span>
                    {language === "en"
                      ? "Commitment to excellence and measurable results that transform your operations"
                      : "Engagement envers l'excellence et les résultats mesurables qui transforment vos opérations"}
                  </span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-accent/5" />
        <div className="container relative z-10">
          <div className="max-w-4xl mx-auto">
            <h2 className="font-display text-4xl text-primary mb-4 text-center">{t.getInTouch}</h2>
            <p className="text-lg text-foreground/80 text-center mb-12">{t.touchDesc}</p>

            <div className="grid md:grid-cols-2 gap-12">
              {/* Contact Information */}
              <div className="space-y-8">
                <div>
                  <h3 className="font-semibold text-primary mb-4">{t.contactInfo}</h3>
                  <div className="space-y-4">
                    <div className="flex items-start gap-4">
                      <Mail className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-primary">{t.emailLabel}</p>
                        <a
                          href="mailto:hello@lumiereglobal.com"
                          className="text-foreground/70 hover:text-accent transition-colors"
                        >
                          hello@lumiereglobal.com
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <Phone className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-primary">{t.phoneLabel}</p>
                        <a
                          href="tel:+1-555-0123"
                          className="text-foreground/70 hover:text-accent transition-colors"
                        >
                          +1 (555) 0123
                        </a>
                      </div>
                    </div>
                    <div className="flex items-start gap-4">
                      <MapPin className="w-5 h-5 text-accent mt-1 flex-shrink-0" />
                      <div>
                        <p className="font-semibold text-primary">{t.location}</p>
                        <p className="text-foreground/70">
                          {language === "en" ? "United States" : "États-Unis"}
                          <br />
                          {language === "en" ? "With Global Reach" : "Avec Portée Mondiale"}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>


              </div>

              {/* Contact Form */}
              <div className="bg-white rounded-xl p-8 border border-border shadow-sm">
                <form onSubmit={handleContactSubmit} className="space-y-6">
                  <div>
                    <label className="block text-sm font-semibold text-primary mb-2">
                      {language === "en" ? "Name" : "Nom"}
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={contactForm.name}
                      onChange={handleContactChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 bg-background"
                      placeholder={language === "en" ? "Your name" : "Votre nom"}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-primary mb-2">
                      {t.emailLabel}
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={contactForm.email}
                      onChange={handleContactChange}
                      required
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 bg-background"
                      placeholder="your@email.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-primary mb-2">
                      {language === "en" ? "Message" : "Message"}
                    </label>
                    <textarea
                      name="message"
                      value={contactForm.message}
                      onChange={handleContactChange}
                      required
                      rows={4}
                      className="w-full px-4 py-2 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent/50 bg-background resize-none"
                      placeholder={
                        language === "en"
                          ? "Tell us about your healthcare facility and needs..."
                          : "Parlez-nous de votre établissement de santé et de vos besoins..."
                      }
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-primary hover:bg-primary/90 text-white rounded-lg transition-all"
                  >
                    {t.sendMessage}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-primary text-white py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <img
                src="/manus-storage/lumiere-logo_744079e8.png"
                alt="Lumière Global"
                className="h-10 w-auto mb-4 brightness-0 invert"
              />
              <p className="text-white/70 text-sm">
                {language === "en"
                  ? "Illuminating Global Solutions in Healthcare Consulting"
                  : "Illuminant les Solutions Mondiales en Conseil en Santé"}
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">{t.services}</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    {language === "en" ? "Systems Integration" : "Intégration des Systèmes"}
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    {language === "en" ? "Optimization" : "Optimisation"}
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    {language === "en" ? "Infrastructure" : "Infrastructure"}
                  </a>
                </li>
                <li>
                  <a href="#services" className="hover:text-white transition-colors">
                    {language === "en" ? "AI Solutions" : "Solutions IA"}
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">{t.company}</h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>
                  <a href="#mission" className="hover:text-white transition-colors">
                    {t.about}
                  </a>
                </li>
                <li>
                  <a href="#community" className="hover:text-white transition-colors">
                    {t.community}
                  </a>
                </li>
                <li>
                  <a href="#contact" className="hover:text-white transition-colors">
                    {t.contact}
                  </a>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">
                {language === "en" ? "Global Reach" : "Portée Mondiale"}
              </h4>
              <ul className="space-y-2 text-sm text-white/70">
                <li>{language === "en" ? "United States" : "États-Unis"}</li>
                <li>{language === "en" ? "Europe" : "Europe"}</li>
                <li>{language === "en" ? "Africa" : "Afrique"}</li>
              </ul>
            </div>
          </div>
          <div className="border-t border-white/10 pt-8 text-center text-sm text-white/70">
            <p>{t.copyright}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
